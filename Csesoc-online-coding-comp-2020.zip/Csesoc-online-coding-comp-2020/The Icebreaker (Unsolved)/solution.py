#!/bin/python3

import math
import os
import random
import re
import sys

#
# Complete the 'icebreaker' function below.
#
# The function accepts following parameters:
#  1. INTEGER xD
#  2. INTEGER yD
#  3. INTEGER zD
#

def icebreaker(xD, yD, zD):
    # Write your code here

if __name__ == '__main__':
    xDimension = int(input().strip())

    yDimension = int(input().strip())

    zDimension = int(input().strip())

    icebreaker(xDimension, yDimension, zDimension)