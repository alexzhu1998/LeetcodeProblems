#!/bin/python3

import math
import os
import random
import re
import sys

#
# Complete the 'assignment' function below.
#
# The function accepts following parameters:
#  1. STRING s
#  2. INTEGER n
#  3. STRING_ARRAY dictionary
#

def assignment(s, n, dictionary):
    # Write your code here

if __name__ == '__main__':
    st = input()

    nm = int(input().strip())

    word_dictionary = input().rstrip().split()

    assignment(st, nm, word_dictionary)
