#!/bin/python3

import math
import os
import random
import re
import sys

#
# Complete the 'train_number' function below.
#
# The function accepts INTEGER n as parameter.
#

def train_number(n):
    # Write your code here

if __name__ == '__main__':
    num = int(input().strip())

    train_number(num)