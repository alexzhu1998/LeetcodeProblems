#!/bin/python3

import math
import os
import random
import re
import sys

#
# Complete the 'calculate_days' function below.
#
# The function accepts following parameters:
#  1. STRING start
#  2. STRING end
#

def calculate_days(start, end):
    # Write your code here

if __name__ == '__main__':
    s = input()

    e = input()

    calculate_days(s, e)